package edu.ub.prog2.CabezasRodrigoNunezJosep.controlador;
//import edu.ub.prog2.utils.ReproductorBasic;
//extends ReproductorBasic
import java.io.Serializable;

public class Reproductor implements Serializable{
    
}
