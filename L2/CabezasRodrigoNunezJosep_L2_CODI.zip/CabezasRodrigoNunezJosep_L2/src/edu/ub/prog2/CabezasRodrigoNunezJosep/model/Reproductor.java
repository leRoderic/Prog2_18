package edu.ub.prog2.CabezasRodrigoNunezJosep.model;
//import edu.ub.prog2.utils.ReproductorBasic;
//extends ReproductorBasic

public class Reproductor {
    
}
