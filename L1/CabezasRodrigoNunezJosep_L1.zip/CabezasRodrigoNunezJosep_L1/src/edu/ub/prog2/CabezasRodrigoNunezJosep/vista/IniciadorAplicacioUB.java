package edu.ub.prog2.CabezasRodrigoNunezJosep.vista;
import java.util.*;

public class IniciadorAplicacioUB {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        AplicacioUB1 aplicacio=new AplicacioUB1();
        aplicacio.gestioAplicacioUB(sc);
    }
}
